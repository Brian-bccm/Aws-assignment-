<?php include('parties/nav.php') ?>

<!-- Main Content Section Starts -->
    <main>

            <h1>MANAGE PARTICIPANTS</h1>
            
            <br>


            <br><br><br>

            <!-- Button to add admin -->
            <a href="#" class="btn-primary">Add Participant</a>

            <br>
            <br>
            <br>

            <table class="tbl-full">
                <tr>
                    <th>S.N.</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Category</th>
                    <th>Action</th>
                </tr>

                
                <tr>
                    <td>1.</td>
                    <td>full_name</td>
                    <td>username</td>
                    <td>dinjun0802@gmail.com</td>
                    <td>Nanquan/Nandao/Nangun</td>
                    <td>
                        <a href="" class="btn-primary">Change Password</a>
                        <a href="" class="btn-secondary">Update User</a> 
                        <a href="" class="btn-danger">Delete User </a>
                    </td>
                </tr>
                
            </table>

    </main>
    <!-- Main Content Section Ends -->

<?php include('parties/footer.php') ?>