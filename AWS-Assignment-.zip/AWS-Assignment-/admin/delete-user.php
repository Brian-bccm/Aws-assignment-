<?php
include('../config/constants.php');

if(isset($_GET['id']))
{
    $id = $_GET['id'];
    $sql2 = "SELECT img FROM tbl_user WHERE id = '$id'";
    $result2 = mysqli_query($conn, $sql2);
    $count = mysqli_num_rows($result2);
    if ($count == 1) {
        $row = mysqli_fetch_assoc($result2);
        $img = $row['img'];
        unlink("../img/user/" . $img);
    }
    $sql1 = "DELETE 
            FROM tbl_user 
            WHERE id = $id";
    $result1 = mysqli_query($conn, $sql1);

    if($result1 == TRUE)
    {
        $_SESSION['delete-user'] = "<h2 class='success'>User Delete Succesfully</h2>";
        header('location:manage-user.php');
    }
    else
    {
        $_SESSION['delete-user'] = "<h2 class='error'>Failed to Delete User</h2>";
        header('location:manage-user.php');
    }
}
else
{
    header('location:manage-user.php');
}
?>