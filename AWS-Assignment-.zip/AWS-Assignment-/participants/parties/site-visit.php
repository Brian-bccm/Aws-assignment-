<?php

function check_site_visit() {
    $count = 0;
    $count++;
    return $count;

    $sql = "SELECT tbl_visit SET quantity=$ WHERE id = 1";
    $sql = "UPDATE tbl_visit SET quantity=$ WHERE id = 1";
}

